Array3d v(-3,5,0);
cout << v.sign() << endl;
